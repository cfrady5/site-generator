# Frames by Frady Site Generator

This is the standalone Vercel project that receives Website Launcher submissions and turns them into static landing page previews.

## Structure

```txt
site-generator/
├── api/
│   └── generate-site.js
├── package.json
├── .env.example
└── README.md
```

## Endpoint

```txt
POST /api/generate-site
```

The request must include:

```txt
x-webhook-secret: your-shared-secret
Content-Type: application/json
```

## Required environment variables

```txt
ANTHROPIC_API_KEY=sk-ant-your-key
GITHUB_TOKEN=ghp_your-token
GITHUB_ORG=your-github-username-or-org
VERCEL_TOKEN=your-vercel-token
WEBHOOK_SECRET=use-the-same-secret-as-framesbyfrady
```

## Recommended email variables

```txt
OWNER_EMAIL=contact@framesbyfrady.com
NOTIFY_EMAIL=contact@framesbyfrady.com
FROM_EMAIL=Frames by Frady <no-reply@framesbyfrady.com>
RESEND_API_KEY=re_your-key
```

## Optional variables

```txt
VERCEL_TEAM_ID=team_your-team-id
CLAUDE_MODEL=claude-sonnet-4-5
```

## Response shape

Success:

```json
{
  "success": true,
  "businessName": "Example Business",
  "projectName": "client-example-business-1710000000000",
  "repoUrl": "https://github.com/your-user/client-example-business-1710000000000",
  "deploymentUrl": "https://client-example-business-1710000000000.vercel.app"
}
```

Failure:

```json
{
  "success": false,
  "error": "Message",
  "stepFailed": "claude_generation"
}
```
